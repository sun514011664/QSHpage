# real-qingshui-pass

<div align="center">
<img src="https://user-images.githubusercontent.com/16968934/100883929-db87c880-34eb-11eb-9a62-049eafefed2f.png"</img>
</div>

## Attention
**介于成都的疫情动态，本 repo 严禁用于清水河校区出入用途，否则使用者个人承担相关法律后果。**

## Try it
[Demo](http://blog.simplenaive.cn/Real-Qingshui-Pass/)

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
